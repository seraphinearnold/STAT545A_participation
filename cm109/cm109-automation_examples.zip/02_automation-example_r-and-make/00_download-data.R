# Download the raw data
library(downloader)
download(url = "http://bit.ly/lotr_raw-tsv", destfile = "lotr_raw.tsv")
